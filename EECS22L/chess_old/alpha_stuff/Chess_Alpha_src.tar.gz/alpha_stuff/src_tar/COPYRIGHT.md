Copyright Notice

Unpublished Work © 2020 by Team 13 

All rights reserved. 

This user manual and program is protected by the U.S. and International copyright laws. No part of this publication may be reproduced or distributed in any form or by any means without prior written permission of the publisher. 

Published by Team 13 members: 
Justin Han, Raymond Yu, Vivek Hatte, Daisuke Otagiri, Hao Ming Chiang
