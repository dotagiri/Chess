int playerVSplayer(void);

int conversion_x(char x_value);

int conversion_y(char y_value);