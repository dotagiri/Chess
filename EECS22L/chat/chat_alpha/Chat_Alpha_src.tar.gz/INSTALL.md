# Installation Guide

* For the End-User Package:
  * Download `Chat_Alpha.tar.gz` located in the `chat` directory
  
* For the Developer/Source Code Package:
  * Download `Chat_Alpha_src.tar.gz` located in the `chat` directory
  
* Type the following in terminal:
  * For End-User Package:
    * `tar -xvzf Chat_Alpha.tar.gz` 
  * For Developer/Source Package:
    * `tar -xvzf Chess_Alpha_src.tar.gz`
  * `make`
* Check the `bin` directory and make sure the `chat` and `chat_server` binary is there
* Begin the chat by running the command `./bin/chat`
