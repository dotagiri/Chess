void pieceRep(const int piece, char* representation);

void displayRow(int board[8][8], const int row);

void displayBoard(int board[8][8]);

void write2Log(int piece, const int prevRow, const int prevCol, const int currRow, const int currCol);

