#ifndef MENU_H
#define MENU_H

int menu_returned_value (void);

#endif
