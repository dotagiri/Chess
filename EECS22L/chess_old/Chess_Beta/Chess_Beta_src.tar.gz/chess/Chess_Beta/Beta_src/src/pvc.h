int playerVScomputer(int menu_returned_value);

