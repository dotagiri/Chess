# Team13

**University of California Irvine**
**EECS 22L - Spring 2020**

Authors: 
  * Justin Han
  * Raymond Yu
  * Vivek Hatte
  * Daisuke Otagiri
  * Hao Ming Chiang
  
 ### Version: 0.0.2 Alpha Release
 ### Date: 04/26/2020

## Introduction
Welcome to Team 13's chess game. To install the game, open `INSTALL.md` for detailed instruction regarding how to install our game.
Refer to the User Manual or Developer's Manual for more details of our program.
