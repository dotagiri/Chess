#ifndef AI_H
#define AI_H

void ai(int board[8][8], int color);

#endif
