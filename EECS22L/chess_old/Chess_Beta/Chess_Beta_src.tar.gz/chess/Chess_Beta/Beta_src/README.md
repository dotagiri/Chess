*NOTE: GUI is yet to be implemented, please refer to `INSTALL.md` for how to run the game*
# Team13

**University of California Irvine**
**EECS 22L - Spring 2020**

## Changes made from Alpha Release:
Compared to our Alpha Release, we were able to finish some typo issues in our print statements and also fixed our user inputs to become more user friendly. The Alpha Release of our program asked the user to input two numbers indicating the row and column in the 2-D array. Now the program will ask for a proper input using the chess board ("a1", "b2"). We've also completed the movement for all our pieces for its legal and illegal moves. The AI and special mvoes function have begun implementation but is still under work. 

Authors: 
  * Justin Han
  * Raymond Yu
  * Vivek Hatte
  * Daisuke Otagiri
  * Hao Ming Chiang
  
 ### Version: 1.0.0 Beta Release
 ### Date: 05/03/2020

## Introduction
Welcome to Team 13's chess game. To install the game, open `INSTALL.md` for detailed instruction regarding how to install our game.
Refer to the User Manual or Developer's Manual for more details of our program.
