#include <stdio.h>
#include <stdlib.h>
#include "menu.h"
#include "moves.h"
#include "board.h"
#include "pvp.h"

int playerVScomputer(int menu_returned_value)
{
	printf("PVC not completed yet \n\n");
	return 0;

//	int initial_x, initial_y;
//	int final_x, final_y;
	
//	int a = 0;  /* checks for checkmate, a = 0 means no checkmate, a = 1 means checkmate */
//	int i = 0 ; /* counter: even is white, odd is black */

//	while (a == 1)
//	{
//		if (i % 2 == 0) /* player turn */
/*		{
			
			printf("Enter the x y coordinates of the piece you want to move(in the form \"x y\": ");		
			scanf("%d %d", &initial_x, &initial_y);
			printf("Enter the x y coordinates of the place you want the piece to end up at(in the form \"x y\": ");
			scanf("%d %d", &final_x, &final_y);
	
			move (board[8][8], initial_x, initial_y, final_x, final_y);
			displayBoard (board[8][8]);
		
			a = checkmate (board[8][8], color, piece);
		}
		
		if (i % 2 != 0)  */ /* AI/computer turn*/
//		{
			
//			a = checkmate (board[8][8], color, piece);
//		}
		
//		i = i + 1 //counter increases to change turns 
		
//	}
		
	// need a return value later that determines whether player or computer won.
//	return 0;
}
