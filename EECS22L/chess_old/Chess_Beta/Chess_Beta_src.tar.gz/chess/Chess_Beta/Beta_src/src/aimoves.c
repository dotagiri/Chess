#include <stdio.h>
#include <stdlib.h>
#include "ChessRules.h"
#include "menu.h"
#include "moves.h"
#include "board.h"
#include "pvp.h"
#include "pvc.h"
#include "aimoves.c"

void king_move(int board[8][8], int color)
{
	int x = 0;	//to iteratre throught the board to find the kings x and y position
	int y = 0;


}
void queen_move(int board[8][8], int color)
{

}
void

