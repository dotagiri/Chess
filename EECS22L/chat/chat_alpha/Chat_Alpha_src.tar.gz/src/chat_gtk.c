//command line to run: gcc chat_gtk.c -o runchat `pkg-config --cflags --libs gtk+-2.0`
//Daisuke: try this command line if it doesn't work:
//gcc 'pkg-config --cflags gtk+-2.0' chat gtk.c -o chat.gtk 'pkg-config --libs gtk+-2.0'
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <netinet/in.h>
#include <netdb.h>
#include <gtk/gtk.h>
#include "UserList.h"

GtkTextBuffer *buffer;
GtkTextIter iter;

/*** global variables***/
const char *Program = NULL; /*program name for descriptive diagnostics*/
int Shutdown = 0;

static void enter_callback( GtkWidget *widget,
                            GtkWidget *entry)
{
  const gchar *entry_text;
  entry_text = gtk_entry_get_text (GTK_ENTRY (entry));
  printf ("Entry contents: %s\n", entry_text);
  
  gtk_text_buffer_insert(buffer, &iter, "\n", -1);
  gtk_text_buffer_insert(buffer, &iter, entry_text, -1);
  gtk_text_buffer_insert(buffer, &iter, "\n", -1);
}

GtkWidget *Create_ChatWindow(int *argc, char **argv[])
{	
    GtkWidget *window;
	GtkWidget *vbox;
    GtkWidget *entry;
    //GtkWidget *button;
	GtkWidget *view;
	
	//gtk_init (&argc, &argv);
	
	window = gtk_window_new (GTK_WINDOW_TOPLEVEL);
	gtk_widget_set_size_request (GTK_WIDGET (window), 700, 350);
    gtk_window_set_title (GTK_WINDOW (window), "Chess Chat Window");
	
	vbox = gtk_vbox_new (FALSE, 0);
    gtk_container_add (GTK_CONTAINER (window), vbox);
    gtk_widget_show (vbox);
	
	view = gtk_text_view_new();
	gtk_box_pack_start(GTK_BOX(vbox), view, TRUE, TRUE, 0);
	gtk_widget_show (view);
	
	//without this line below, segmentation fault occurs
    buffer = gtk_text_view_get_buffer(GTK_TEXT_VIEW(view));
	gtk_text_buffer_get_iter_at_offset(buffer, &iter, 0);
	
	
	g_signal_connect (window, "destroy",
                      G_CALLBACK (gtk_main_quit), NULL);
    g_signal_connect_swapped (window, "delete-event",
                              G_CALLBACK (gtk_widget_destroy), window);
	
	entry = gtk_entry_new ();
    gtk_entry_set_max_length (GTK_ENTRY (entry), 50);
    g_signal_connect (entry, "activate",
		      G_CALLBACK (enter_callback), entry);		  
	gtk_text_buffer_insert(buffer, &iter, "Hello, welcome to chess chat\n", -1);			
	gtk_box_pack_start (GTK_BOX (vbox), entry, TRUE, TRUE, 0);
    gtk_widget_show (entry);
	
	/*
	button = gtk_button_new_from_stock (GTK_STOCK_CLOSE);
    g_signal_connect_swapped (button, "clicked",
			      G_CALLBACK (gtk_widget_destroy),
			      window);
	gtk_box_pack_start (GTK_BOX (vbox), button, TRUE, TRUE, 0);
    gtk_widget_set_can_default (button, TRUE);
    gtk_widget_grab_default (button);
    gtk_widget_show (button);
    */
	
    gtk_widget_show  (window);
    
    gtk_main ();

	return window;
} /*end of Create_ChatWindow*/

GtkWidget *Create_RegisterWindow(int *argc, char **argv[])
{
	GtkWidget *Window;
	GtkWidget *VBox, *VBox1, *VBox2, *VBox3, *VBox4;
	GtkWidget *Label1, *Label2, *Label3;
	GtkWidget *entry1, *entry2, *entry3;
	GtkWidget *button;
	
	Window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
	gtk_window_set_title(GTK_WINDOW(Window), "Register");
	gtk_window_set_position(GTK_WINDOW(Window), GTK_WIN_POS_CENTER);
	gtk_widget_set_size_request(Window, 480, 270);

	VBox = gtk_vbox_new(FALSE,0);
	gtk_container_add(GTK_CONTAINER(Window), VBox);
	VBox1 = gtk_hbox_new(FALSE,0);
	gtk_box_pack_start(GTK_BOX(VBox), VBox1, TRUE, TRUE, 10);
	VBox2 = gtk_hbox_new(FALSE,0);
	gtk_box_pack_start(GTK_BOX(VBox), VBox2, TRUE, TRUE, 10);
	VBox3 = gtk_hbox_new(FALSE,0);
	gtk_box_pack_start(GTK_BOX(VBox), VBox3, FALSE, FALSE, 10);
	VBox4 = gtk_hbox_new(FALSE,0);
	gtk_box_pack_start(GTK_BOX(VBox), VBox4, FALSE, FALSE, 10);

	Label1 = gtk_label_new("Username: ");
	entry1 = gtk_entry_new();
	gtk_box_pack_start(GTK_BOX(VBox1), Label1, FALSE, FALSE, 5);
	gtk_box_pack_start(GTK_BOX(VBox1), entry1, FALSE, FALSE, 5);

	Label2 = gtk_label_new("Password: ");
	entry2 = gtk_entry_new();
	gtk_entry_set_visibility(GTK_ENTRY(entry2), FALSE);
	gtk_box_pack_start(GTK_BOX(VBox2), Label2, FALSE, FALSE, 5);
	gtk_box_pack_start(GTK_BOX(VBox2), entry2, FALSE, FALSE, 5);

	Label3 = gtk_label_new("Retype Password: ");
	entry3 = gtk_entry_new();
	gtk_entry_set_visibility(GTK_ENTRY(entry2), FALSE);
	gtk_box_pack_start(GTK_BOX(VBox3), Label3, FALSE, FALSE, 5);
	gtk_box_pack_start(GTK_BOX(VBox3), entry3, FALSE, FALSE, 5);

	button = gtk_button_new_with_label("Cancel");
	g_signal_connect(G_OBJECT(button), "clicked", G_CALLBACK(gtk_widget_destroy), Window);
	gtk_box_pack_start(GTK_BOX(VBox3), button, TRUE, TRUE, 10);
	gtk_widget_show(button);

	button = gtk_button_new_with_label("Register");
//	g_signal_connect(G_OBJECT(button), "clicked", G_CALLBACK(login function here), (gpointer)6);		
//	g_signal_connect_swapped(G_OBJECT(button), "clicked", G_CALLBACK(hide), Window);
	gtk_box_pack_start(GTK_BOX(VBox3), button, TRUE, TRUE, 5);
	gtk_widget_show(button);
	
	return Window;
} /*of Create_RegisterWindow*/

GtkWidget *Create_LoginWindow(int *argc, char **argv[])
{
	GtkWidget *Window;
	GtkWidget *VBox, *VBox1, *VBox2, *VBox3;
	GtkWidget *entry1, *entry2;
	GtkWidget *Label1, *Label2;
	GtkWidget *button;
	
	Window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
	g_signal_connect(G_OBJECT(Window), "destroy", G_CALLBACK(gtk_main_quit), NULL);
	gtk_window_set_title(GTK_WINDOW(Window), "Login");
	gtk_window_set_position(GTK_WINDOW(Window), GTK_WIN_POS_CENTER);
	gtk_widget_set_size_request(Window, 480, 270);	
	
	VBox = gtk_vbox_new(FALSE, 0);
	gtk_container_add(GTK_CONTAINER(Window), VBox);
	VBox1 = gtk_hbox_new(FALSE, 0);
	gtk_box_pack_start(GTK_BOX(VBox), VBox1, TRUE, TRUE, 10);
	VBox2 = gtk_hbox_new(FALSE, 0);
	gtk_box_pack_start(GTK_BOX(VBox), VBox2, TRUE, TRUE, 10);
	VBox3 = gtk_hbox_new(FALSE, 0);
	gtk_box_pack_start(GTK_BOX(VBox), VBox3, FALSE, FALSE, 10);

	Label1 = gtk_label_new("Username: ");
	entry1 = gtk_entry_new();
	gtk_box_pack_start(GTK_BOX(VBox1), Label1, FALSE, FALSE, 5);
	gtk_box_pack_start(GTK_BOX(VBox1), entry1, FALSE, FALSE, 5);
	
	Label2 = gtk_label_new("Password: ");
	entry2 = gtk_entry_new();
	gtk_entry_set_visibility(GTK_ENTRY(entry2), FALSE);
	gtk_box_pack_start(GTK_BOX(VBox2), Label2, FALSE, FALSE, 5);
	gtk_box_pack_start(GTK_BOX(VBox2), entry2, FALSE, FALSE, 5);
	
	button = gtk_check_button_new_with_label("Log in");
//	g_signal_connect(G_OBJECT(button), "clicked", G_CALLBACK(login function here), (gpointer));
	gtk_box_pack_start(GTK_BOX(VBox3), button, TRUE, TRUE, 5);
	gtk_widget_show(button);
	
	return Window;
} /*end of Create_LoginWindow*/

GtkWidget *Add_UserWindow(int argc, char *argv[])
{
	GtkWidget *Window;
	GtkWidget *VBox, *VBox1;
	GtkWidget *Label1;
	GtkWidget *entry1;
	GtkWidget *button;
	
	Window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
	gtk_window_set_title(GTK_WINDOW(Window), "Chess Chat Add User/Friend");
	gtk_widget_set_size_request (GTK_WIDGET (Window), 700, 350);
	
	VBox = gtk_vbox_new(FALSE,0);
	gtk_container_add(GTK_CONTAINER(Window), VBox);
	VBox1 = gtk_hbox_new(FALSE,0);
	gtk_box_pack_start(GTK_BOX(VBox), VBox1, TRUE, TRUE, 10);
	
	Label1 = gtk_label_new("Username of friend to add: ");
	entry1 = gtk_entry_new();
	g_signal_connect (entry1, "activate",
		      G_CALLBACK (gtk_widget_destroy), entry1);		  
	gtk_box_pack_start(GTK_BOX(VBox1), Label1, FALSE, FALSE, 5);
	gtk_box_pack_start(GTK_BOX(VBox1), entry1, FALSE, FALSE, 5);
	

	button = gtk_button_new_with_label("Cancel");
	button = gtk_button_new_from_stock (GTK_STOCK_CLOSE);
    g_signal_connect_swapped (button, "clicked",
			      G_CALLBACK (gtk_widget_destroy),
			      Window);
	gtk_box_pack_start (GTK_BOX (VBox), button, TRUE, TRUE, 10);
    gtk_widget_set_can_default (button, TRUE);
    gtk_widget_grab_default (button);
    gtk_widget_show (button);
	
	gtk_widget_show_all (Window);
	
	return Window;
}

void FatalError(		/* print error diagnostics and abort */
	const char *ErrorMsg)
{
    fputs(Program, stderr);
    fputs(": ", stderr);
    perror(ErrorMsg);
    fputs(Program, stderr);
    fputs(": Exiting!\n", stderr);
    exit(20);
} /* end of FatalError */

int main( int argc, char *argv[] )
{
	GtkWidget *Chat_Window  = NULL;
	GtkWidget *Register_Window = NULL;
	GtkWidget *Login_Window = NULL;
//	int ServSocketFD; /*socket file descriptor for service*/
	int PortNo;	  /*port number*/

	Program = argv[0];
	gtk_init (&argc, &argv);
	
#ifdef DEBUG
	printf("%s: Starting...\n", Program);
#endif
	if (argc < 2){
		fprintf(stderr, "Usage: %s port\n", Program);
		exit(10);
		} /*fi*/ 
	PortNo = atoi(argv[1]); /*get port number*/
	if (PortNo<= 2000){	
		fprintf(stderr, "%s: invalid port number %d, should be >2000\n", Program, PortNo);	
		exit(10);
		} /*fi*/
#ifdef DEBUG
	printf("%s: Creating Chat Window...\n", Program);
#endif	
	Chat_Window = Create_ChatWindow(&argc, &argv);
	if (!Chat_Window){
		fprintf(stderr, "%s: cannot create GUI window\n", Program);
		} /*fi*/
#ifdef DEBUG
	printf("%s: Creating Register Window...\n", Program);
#endif
	Register_Window = Create_RegisterWindow(&argc, &argv);
	if (!Register_Window){
		fprintf(stderr, "%s: cannote create GUI window\n", Program);
		} /*fi*/

#ifdef DEBUG
	printf("%s: Creating Login Window...\n", Program);
#endif
	Login_Window = Create_LoginWindow(&argc, &argv);
	if(!Login_Window){
		fprintf(stderr, "%s: cannote create GUI window\n", Program);
		} /*fi*/
	
   return 0;
} /*end of main*/
