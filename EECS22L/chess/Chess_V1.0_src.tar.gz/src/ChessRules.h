void ChessRules(void);
