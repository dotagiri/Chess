# Team13

**University of California Irvine**
**EECS 22L - Spring 2020**

Authors: 
  * Justin Han
  * Raymond Yu
  * Vivek Hatte
  * Daisuke Otagiri
  * Hao Ming Chiang
  
 ### Version: v1.0.0 Alpha Release
 ### Date: 05/31/2020

## Introduction
Welcome to Team 13's chat feature for the chess game. To install the chat, open `INSTALL.md` for detailed instruction regarding how to install our game.
Refer to the User Manual or Developer's Manual for more details of our program.
