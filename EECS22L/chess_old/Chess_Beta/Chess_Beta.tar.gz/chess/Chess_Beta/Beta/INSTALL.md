# Installation Guide

* Downlaod and extract Chess_Beta.tar.gz
* Type the following in terminal:
  * `tar -xvzf Chess_Beta_src.tar.gz`
  * `cd Chess_Beta_src`
  * `make`
* Open the `bin` directory and make sure the `chess` binary is there
* Begin the game by running the command `./chess`
