# Installation Guide

* Downlaod and extract Chess_Alpha.tar.gz
* Type the following in terminal:
  * `tar -xvzf Chess_Alpha.tar.gz`
  * `cd Chess_Alpha`
  * `make`
* Open the `bin` directory and make sure the `chess` binary is there
* Begin the game by running the command `./chess`
