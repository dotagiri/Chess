#include <stdio.h>
#include <stdlib.h>
#include "ChessRules.h"
#include "menu.h"
#include "moves.h"
#include "board.h"
#include "pvp.h"
#include "pvc.h"



void ai(int board[8][8], int color)
{
	if(color == 0) //moves a white peice
	{


	}
	else if(color == 1) //moves a black peice
	{


	}
}
