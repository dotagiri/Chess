int playerVSplayer(void);

int playerVScomputer(int x);

void ChessRules(void);
